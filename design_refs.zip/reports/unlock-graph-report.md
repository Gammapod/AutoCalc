Unlock Graph Report
Generated: 2026-03-10T07:30:51.430Z

Graph Summary
- Nodes: key=24, function=16, condition=28, sufficient_set=16, effect_target=1
- Edges: necessary=34, sufficient=51, requires=47, unlocks=28

Progression Summary
- Starting keys: ++, CIRCLE
- Reachable conditions: 25
- Blocked conditions: 3
- Keys reachable from simulation: -, --, *, #, ←, +, ++, =, ⟡, 0, 1, 4, C, CIRCLE, M–, M+, UNDO, α,β,γ
- Unreachable keys: /, ALG, CE, NEG, e, pi
- Effect targets reached: effect.allocator.max_points
- Effect targets unreachable: (none)

Blocked Conditions
- unlock_neg_on_alt_sign_abs_run_7: missing fn.roll_alternating_sign_constant_abs
- unlock_ce_on_first_division_by_zero: missing fn.division_by_zero_error
- unlock_alg_visualizer_on_first_symbolic_result: missing fn.symbolic_result_error

Detected Key Cycles
- -- -> +
- * -> # -> ⟡
- NEG